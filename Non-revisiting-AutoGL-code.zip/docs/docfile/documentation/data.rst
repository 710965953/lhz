.. _data documentation:

data
====

.. automodule:: autogl.data
   :members: