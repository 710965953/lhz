.. _solver documentation:

solver
======

.. automodule:: autogl.solver
    :members: