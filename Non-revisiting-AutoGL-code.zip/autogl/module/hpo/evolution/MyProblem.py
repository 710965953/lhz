# -*- coding: utf-8 -*-
"""MyProblem.py"""
import numpy as np
import geatpy as ea
import multiprocessing as mp
from multiprocessing import Pool as ProcessPool
from multiprocessing.dummy import Pool as ThreadPool
import math
import optuna
from optuna.distributions import UniformDistribution

class MyProblem(ea.Problem): # 继承Problem父类
    def __init__(self, fn, dataset,  _decode_para,
                 name_record, single_choice_para, 
                 Dim, **kwargs):#Dim（决策变量维数）
        name = 'HPO' # 初始化name（函数名称，可以随意设置）
        M = 2 # 初始化M（目标维数）
        maxormins = [1] * M # 初始化目标最小最大化标记列表，1：min；-1：max
        # 初始化决策变量类型，0：连续；1：离散
        kwargs = kwargs["kwargs"]
        varTypes = kwargs.get("varTypes", [0] * Dim)
        # 决策变量下界
        lb = kwargs.get("lb", None)
        # 决策变量上界
        ub = kwargs.get("ub", None)
        # 决策变量下边界
        lbin = kwargs.get("lbin", None)
        # 决策变量上边界
        ubin = kwargs.get("ubin", None)
        
        self.name_record = name_record
        self.single_choice_para = single_choice_para
        self.dataset = dataset
        self.fn = fn
        self._decode_para = _decode_para
        self.lb = lb
        self.ub = ub
        
        # 调用父类构造方法完成实例化s
        ea.Problem.__init__(self, name, M, maxormins, Dim, varTypes, lb,
                            ub, lbin, ubin)

        #试试多线程会不会快很多呢
        self.pool = ThreadPool(4)

    def aimFunc(self, pop): # 目标函数，pop为传入的种群对象
        hpsGroup = []
        Phen = pop.Phen
        row, col = Phen.shape
        for i in range(row):
            hps = {}
            for j in range(col):
                hps[self.name_record[j]] = Phen[[i],[j]]
            hps.update(self.single_choice_para) #只有一个选项的哈批东西
            hpsGroup.append(hps)
        pop.ObjV = np.array(list(self.pool.map(self.subaimFunc, hpsGroup)))

    def subaimFunc(self, hps):
        for t in hps:
            if isinstance(hps[t], list):
                hps[t] = hps[t][0]
            elif isinstance(hps[t], np.ndarray):
                hps[t] = hps[t].tolist()[0] #转成正常的格式
        para_for_trainer, para_for_hpo = self._decode_para(hps)
        _, acc, loss = self.fn(self.dataset, para_for_trainer)
        return [acc, loss]

class MyProblem_single(ea.Problem): # 继承Problem父类
    def __init__(self, fn, dataset,  _decode_para,
                 name_record, single_choice_para, 
                 Dim, **kwargs):#Dim（决策变量维数）
        name = 'HPO_s' # 初始化name（函数名称，可以随意设置）
        M = 1 # 初始化M（目标维数）
        maxormins = [1] * M # 初始化目标最小最大化标记列表，1：min；-1：max
        # 初始化决策变量类型，0：连续；1：离散
        kwargs = kwargs["kwargs"]
        varTypes = kwargs.get("varTypes", [0] * Dim)
        # 决策变量下界
        lb = kwargs.get("lb", None)
        # 决策变量上界
        ub = kwargs.get("ub", None)
        # 决策变量下边界
        lbin = kwargs.get("lbin", None)
        # 决策变量上边界
        ubin = kwargs.get("ubin", None)
        
        self.name_record = name_record
        self.single_choice_para = single_choice_para
        self.dataset = dataset
        self.fn = fn
        self.lb = lb
        self.ub = ub
        self._decode_para = _decode_para
        
        # 调用父类构造方法完成实例化s
        ea.Problem.__init__(self, name, M, maxormins, Dim, varTypes, lb,
                            ub, lbin, ubin)
        #试试多线程会不会快很多呢
        self.pool = ThreadPool(1)


    # def calReferObjV(self):
    #     # x1 = np.array([-1.0])
    #     # x2 = np.array([0.0])
    #     return np.hstack([-1.0, 0.0])

    def aimFunc(self, pop): # 目标函数，pop为传入的种群对象
        hpsGroup = []
        Phen = pop.Phen
        row, col = Phen.shape
        for i in range(row):
            hps = {}
            for j in range(col):
                hps[self.name_record[j]] = Phen[[i],[j]]
            # print(hps)
            hps.update(self.single_choice_para) #只有一个选项的哈批东西
            hpsGroup.append(hps)
        pop.ObjV = np.array(list(self.pool.map(self.subaimFunc, hpsGroup)))

    def subaimFunc(self, hps):
        for t in hps:
            if isinstance(hps[t], list):
                hps[t] = hps[t][0]
            elif isinstance(hps[t], np.ndarray):
                hps[t] = hps[t].tolist()[0] #转成正常的格式
        para_for_trainer, para_for_hpo = self._decode_para(hps)
        _, acc = self.fn(self.dataset, para_for_trainer)
        return [acc]  #仅使用acc作为评价依据

    def bayesFunc(self,hps):
        hps['num_layers_'] = '0'
        para_for_trainer, para_for_hpo = self._decode_para(hps)
        _, acc = self.fn(self.dataset, para_for_trainer)
        return [acc]  #仅使用acc作为评价依据

    def bayesFuncTest(self,trialList:list):
        def objective(trial):
            max_epoch_ = trial.suggest_float("max_epoch_", 100, 200)
            early_stopping_round_ = trial.suggest_float("early_stopping_round_", 10, 30)
            lr_ = trial.suggest_float("lr_", -5.298317366548036, -2.995732273553991)
            weight_decay_ = trial.suggest_float("weight_decay_", -9.210340371976182, -6.907755278982137)
            hidden_0 = trial.suggest_float("hidden_0", 3.4657359027997265, 4.852030263919617)
            dropout_ = trial.suggest_float("dropout_", 0.2, 0.8)
            act_ = trial.suggest_float("act_", 0, 4)

            hps = {}
            hps['max_epoch_'] = max_epoch_
            hps['early_stopping_round_'] = early_stopping_round_
            hps['lr_'] = lr_
            hps['weight_decay_'] = weight_decay_
            hps['hidden_0'] = hidden_0
            hps['dropout_'] = dropout_
            hps['act_'] = act_
            acc = self.bayesFunc(hps)
            return math.fabs(acc[0])

        study = optuna.create_study(direction='maximize')
        assert len(study.trials) == 0
        # paraset = [150, 12, -4, -7, 3.8, 0.5, 3]
        # trial = optuna.trial.create_trial(
        #     params={'max_epoch_': paraset[0],
        #             'early_stopping_round_': paraset[1],
        #             'lr_': paraset[2],
        #             'weight_decay_': paraset[3],
        #             'hidden_0': paraset[4],
        #             'dropout_': paraset[5],
        #             'act_': paraset[6]},
        #     distributions={'max_epoch_': UniformDistribution(100, 200),
        #                    'early_stopping_round_': UniformDistribution(10, 30),
        #                    'lr_': UniformDistribution(-5.298317366548036, -2.995732273553991),
        #                    'weight_decay_': UniformDistribution(-9.210340371976182, -6.907755278982137),
        #                    'hidden_0': UniformDistribution(3.4657359027997265, 4.852030263919617),
        #                    'dropout_': UniformDistribution(0.2, 0.8),
        #                    'act_': UniformDistribution(0, 4)},
        #     value=300,
        # )
        for trial in trialList:
            study.add_trial(trial)

        study.optimize(objective, n_trials=30)

        return study.trials[-1].params,study.trials[-1].value
        # other_study = optuna.create_study()
        #
        # for trial in study.trials:
        #     other_study.add_trial(trial)
        # assert len(other_study.trials) == len(study.trials)
        #
        # other_study.optimize(objective, n_trials=2)
        # assert len(other_study.trials) == len(study.trials) + 2