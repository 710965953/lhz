# -*- coding: utf-8 -*-
import numpy as np

import geatpy as ea  # 导入geatpy库

from sys import path as paths
import sys

from optuna.distributions import UniformDistribution

sys.setrecursionlimit(15000) # 设置最大递归深度为15000
from os import path
from .bsd_tree import *
import optuna

class soea_EGA_templet(ea.SoeaAlgorithm):
    """
    soea_EGA_templet.py - Elitist Reservation GA Algorithm (精英保留的遗传算法类).
    算法描述:
        本算法类实现的是基于杰出保留的单目标遗传算法。算法流程如下：
        1) 根据编码规则初始化N个个体的种群。
        2) 若满足停止条件则停止，否则继续执行。
        3) 对当前种群进行统计分析，比如记录其最优个体、平均适应度等等。
        4) 独立地从当前种群中选取N-1个母体。
        5) 独立地对这N-1个母体进行交叉操作。
        6) 独立地对这N-1个交叉后的个体进行变异。
        7) 计算当代种群的最优个体，并把它插入到这N-1个交叉后的个体的第一位，得到新一代种群。
        8) 回到第2步。
    """

    def __init__(self, problem, population):
        ea.SoeaAlgorithm.__init__(self, problem, population)  # 先调用父类构造方法
        if population.ChromNum != 1:
            raise RuntimeError('传入的种群对象必须是单染色体的种群类型。')
        self.name = 'EGA'
        self.selFunc = 'tour'  # 锦标赛选择算子
        if population.Encoding == 'P':
            self.recOper = ea.Xovpmx(XOVR=0.7)  # 生成部分匹配交叉算子对象
            self.mutOper = ea.Mutinv(Pm=0.5)  # 生成逆转变异算子对象
        else:
            self.recOper = ea.Xovdp(XOVR=0.7)  # 生成两点交叉算子对象
            if population.Encoding == 'BG':
                self.mutOper = ea.Mutbin(
                    Pm=None)  # 生成二进制变异算子对象，Pm设置为None时，具体数值取变异算子中Pm的默认值
            elif population.Encoding == 'RI':
                self.mutOper = ea.Mutbga(Pm=1 / self.problem.Dim,
                                         MutShrink=0.5,
                                         Gradient=20)  # 生成breeder GA变异算子对象
            else:
                raise RuntimeError('编码方式必须为'
                                   'BG'
                                   '、'
                                   'RI'
                                   '或'
                                   'P'
                                   '.')
        self.FitnessTree = BSPTree()
        self.FitnessTree.setMaxandMin(lb = problem.lb, ub = problem.ub)

    def run(self, prophetPop=None):  # prophetPop为先知种群（即包含先验知识的种群）
        # ==========================初始化配置===========================
        population = self.population
        NIND = population.sizes
        self.initialization()  # 初始化算法类的一些动态参数
        # ===========================准备进化============================
        population.initChrom(NIND)  # 初始化种群染色体矩阵
        # 插入先验知识（注意：这里不会对先知种群prophetPop的合法性进行检查）
        if prophetPop is not None:
            population = (prophetPop + population)[:NIND]  # 插入先知种群
        self.call_aimFunc(population)  # 计算种群的目标函数值
        population.FitnV = ea.scaling(population.ObjV,
                                      population.CV,
                                      self.problem.maxormins)  # 计算适应度
        # 非重访 BSP
        row, col = population.Chrom.shape
        for i in range(row):
            newNode = Tree_node(fitness=-population.ObjV[i], paraset=population.Chrom[i])
            self.FitnessTree.insertNode(newNode)
        self.FitnessTree.buildOptimSet()  # 更新optimset
        i_n = 0
        # ===========================开始进化============================
        while not self.terminated(population):
            i_n += 1
            historySolutionNum = i_n * NIND
            self.FitnessTree.setL(min(28, self.FitnessTree.L + 2 * (historySolutionNum // 40)))
            bestIndi = population[np.argmax(population.FitnV, 0)]  # 得到当代的最优个体
            # 选择
            offspring = population[ea.selecting(self.selFunc,
                                                population.FitnV,
                                                NIND - 1)]
            # 进行进化操作
            offspring.Chrom = self.recOper.do(offspring.Chrom)  # 重组
            offspring.Chrom = self.mutOper.do(offspring.Encoding,
                                              offspring.Chrom,
                                              offspring.Field)  # 变异

            PopList = self.FitnessTree.getTreeNode()

            num = []
            R_fitness = []
            for i in range(len(offspring.Chrom)):
                for temp in PopList:
                    points = zip(offspring.Chrom[i], temp.paraset)
                    diffs_squared_distance = [pow(a - b, 2) for (a, b) in points]
                    dis = math.sqrt(sum(diffs_squared_distance))
                    if dis < 1:
                        ###非重访+贝叶斯
                        # tempParaset,fiv = self.call_bayes(trials)
                        # newParset = []
                        # newParset.append(tempParaset['max_epoch_'])
                        # newParset.append(tempParaset['early_stopping_round_'])
                        # newParset.append(tempParaset['lr_'])
                        # newParset.append(tempParaset['weight_decay_'])
                        # newParset.append(tempParaset['hidden_0'])
                        # newParset.append(tempParaset['dropout_'])
                        # newParset.append(tempParaset['act_'])
                        # experimentPop.Chrom[i] = newParset
                        ####非重访
                        num.append(i)
                        R_fitness.append(-temp.fitness)
                        # 可能不止一个相似点，必须要加break，否则会对种群规模有影响
                        break
            R_experimentPop = ea.Population(population.Encoding, population.Field, len(num))
            N_experimentPop = ea.Population(population.Encoding, population.Field, NIND - 1 - len(num))
            R_num = 0
            R_Chrom = []
            R_Objv = []
            N_Chrom = []
            for t in range(NIND - 1):
                if t in num:
                    R_Chrom.append(offspring.Chrom[t])
                    R_Objv.append(R_fitness[R_num])
                    R_num += 1
                else:
                    N_Chrom.append(offspring.Chrom[t])
            R_experimentPop.Chrom = np.array(R_Chrom)
            R_experimentPop.ObjV = np.array(R_Objv)
            N_experimentPop.Chrom = np.array(N_Chrom)
            if N_experimentPop.sizes < 10:
                break

            self.call_aimFunc(N_experimentPop)  # 计算目标函数值

            if R_experimentPop.sizes != 0:
                offspring = R_experimentPop + N_experimentPop
            else:
                offspring = N_experimentPop

            population = bestIndi + offspring  # 更新种群
            population.FitnV = ea.scaling(population.ObjV,
                                          population.CV,
                                          self.problem.maxormins)  # 计算适应度

            for i in range(population.Chrom.shape[0]):
                newNode = Tree_node(fitness=-population.ObjV[i], paraset=population.Chrom[i])
                self.FitnessTree.insertNode(newNode)
            self.FitnessTree.buildOptimSet()    #更新optimset
        return self.finishing(population)  # 调用finishing完成后续工作并返回结果