import numpy as np
import random
import networkx as nx
import matplotlib.pyplot as plt
import math

class Tree_node():
    def __init__(self,fitness, paraset):
        self.fitness = fitness
        self.paraset = paraset
        self.lchild = None
        self.rchild = None
        self.parent = None
        self.dividDim = None
    
    def has2son(self):
        return (self.lchild is not None) and (self.rchild is not None)
    @property
    def getfitness(self):
        return self.fitness
    @property
    def getPara(self):
        return self.paraset
    def isLeaf(self):
        return (self.lchild is None) and (self.rchild is None)
    def trans2midNode(self, lnode, rnode, dividDim):
        self.fitness = None
        self.paraset = None
        self.lchild = lnode
        self.rchild = rnode
        self.dividDim = dividDim

class BSPTree():
    def __init__(self):
        self.L = 4
        self.root = None
        self.nodeDim = None

    def setL(self, Lvalue: int) -> None:
        self.L = Lvalue

    def setMaxandMin(self, lb: list, ub: list):
        self.lb = lb
        self.ub = ub
        self.bdiff = (np.array(ub) - np.array(lb)).tolist()
    def _getMaxDiffDim(self, son1: Tree_node, son2:Tree_node):
        """
        Comparing dimension j :=arg max
        k∈[1,D]|a(k) − b(k)|

        TODO: Regular
        Regular method:
            pass the max and min value to this function, and use judge the differece betwwen dimensions.
        """
        maxDiff = 0
        maxDiffDim = -1
        for j in range(self.nodeDim):
            s1p = (son1.paraset[j] - self.lb[j]) / self.bdiff[j]
            s2p = (son2.paraset[j] - self.lb[j]) / self.bdiff[j]
            tempDiff = abs(s1p - s2p)
            if tempDiff > maxDiff:
                maxDiff = tempDiff
                maxDiffDim = j
        return maxDiffDim

    def _getAleaf(self, node: Tree_node):
        tnode = node
        while not tnode.isLeaf():
            tnode = tnode.lchild
        return tnode

    def searchNode(self, paraSet) -> Tree_node:
        currNode = self.root
        while currNode.has2son():
            dim = currNode.dividDim
            lnode = self._getAleaf(currNode.lchild)
            rnode = self._getAleaf(currNode.rchild)
            if abs(lnode.paraset[dim] - paraSet[dim]) <= abs(rnode.paraset[dim] - paraSet[dim]):
                currNode = currNode.lchild
            else:
                currNode = currNode.rchild
        return currNode

    def insertNode(self, new_node: Tree_node):
        if self.root is None:
            self.root = new_node
            self.nodeDim = len(self.root.paraset)
        else:
            tempNode = self.searchNode(new_node.paraset)
            tempL = Tree_node(tempNode.fitness, tempNode.paraset)
            tempL.parent = tempNode
            tempR = new_node
            tempR.parent = tempNode
            dim = self._getMaxDiffDim(tempL, tempR)
            tempNode.trans2midNode(tempL, tempR, dim)

    def _getNeighborhood(self, node: Tree_node) -> list:
        neighborList = []
        currNode = node
        for i in range(self.L):
            if currNode.parent != None:
                currNode = currNode.parent
            else:
                break
        #Now the current Node is the temp root node
        def preOrder(tempNode: Tree_node):
            if tempNode != None:
                if tempNode.isLeaf():
                    neighborList.append(tempNode)
                preOrder(tempNode.lchild)
                preOrder(tempNode.rchild)
        preOrder(currNode)
        return neighborList
    
    def _isOptimal(self, Xnode: Tree_node) -> bool:
        neighborList = self._getNeighborhood(Xnode)
        bestFit = -float('inf')
        bestIndentity = None
        for node in neighborList:
            if node.fitness > bestFit:
                # print(node.fitness)
                bestIndentity = node
                bestFit = node.fitness
        return Xnode is bestIndentity

    def showOptimFitness(self):
        for n in self.optimSet:
            print(n.fitness, end = '  ')
        print('')

    def buildOptimSet(self):
        self.optimSet = []
        leafs = []
        def preOrder(node: Tree_node):
            if node is not None:
                if node.isLeaf():
                    leafs.append(node)
                preOrder(node.lchild)
                preOrder(node.rchild)
        preOrder(self.root)
        for leaf in leafs:
            if self._isOptimal(leaf):
                self.optimSet.append(leaf)

    def _hasTheSon(self, parentNode: Tree_node, sonNode: Tree_node):
        tempNode = sonNode
        while tempNode is not None:
            if tempNode == parentNode:
                return True
            tempNode = tempNode.parent
        return False

    def _getDistance(self, xnode: Tree_node, ynode: Tree_node):
        currNode = xnode
        depth = 0
        while currNode is not None:
            if self._hasTheSon(currNode, ynode):
                return depth
            else:
                depth += 1
                currNode = currNode.parent
        return depth

    def getNearestOptim(self, node: Tree_node) -> Tree_node:
        smallestDistance = float('inf')
        nearestOptimNode = None
        for optimNode in self.optimSet:
            tempDistance = self._getDistance(node, optimNode)
            if tempDistance < smallestDistance:
                smallestDistance = tempDistance
                nearestOptimNode = optimNode
        return nearestOptimNode

    def getTreeNode(self) -> list:
        treeNodeList = []
        def preOrder(tempNode: Tree_node):
            if tempNode != None:
                if tempNode.isLeaf():
                    treeNodeList.append(tempNode)
                preOrder(tempNode.lchild)
                preOrder(tempNode.rchild)
        preOrder(self.root)
        return treeNodeList

    def drawTreePic(self, save_dir: str) -> None:
        def create_graph(G, node : Tree_node, pos={}, x=0, y=0, layer=1):
            node_value = int(node.fitness) if node.isLeaf() else -1
            pos[node_value] = (x, y)
            if node.lchild:
                G.add_edge(node_value, int(node.lchild.fitness) if node.lchild.isLeaf() else -1)
                l_x, l_y = x - 1 / 2 ** layer, y - 1
                l_layer = layer + 1
                create_graph(G, node.lchild, x=l_x, y=l_y, pos=pos, layer=l_layer)
            if node.rchild:
                G.add_edge(node_value, int(node.rchild.fitness) if node.rchild.isLeaf() else -1)
                r_x, r_y = x + 1 / 2 ** layer, y - 1
                r_layer = layer + 1
                create_graph(G, node.rchild, x=r_x, y=r_y, pos=pos, layer=r_layer)
            return (G, pos)
        def draw(node):   # 以某个节点为根画图
            graph = nx.DiGraph()
            graph, pos = create_graph(graph, node)
            fig, ax = plt.subplots(figsize=(8, 10))  # 比例可以根据树的深度适当调节
            nx.draw_networkx(graph, pos, ax=ax, node_size=500)
            plt.savefig(save_dir)
            plt.show()
        draw(self.root)
        


def GAS(x: Tree_node, Tree: BSPTree):
    """
    Algorithm A3: GAS
    Input: 1) An individual x, 2) fitness tree T
    1. {si} := The evaluated solution set stored in T
    2. H = ∪ihi := The partitioned sub-region set where hi is
    the sub-region of si
    /* Search for the nearest optimal sub-region y of x */
    3. Search for the sub-region h ⊆ H of x
    4. Find the nearest optimal sub-region of h
    5. y := The evaluated solution inside h
    /* End of Search for the nearest optimal sub-region y of x */
    6. If (x = y)
    7. m : = Random(h)
    8. Else
    9. α := Random((0, 1))
    10. m := αx + (1 − α)y
    11. End
    Output: The mutated individual m
    
    """
    #Find the Sub-Region of x
    y = Tree.getNearestOptim(x).paraset
    if all(x.paraset != y):
        alpha = random.random()
        m = alpha * x.paraset + (1 - alpha) * y
        return m
    return x.paraset


def PreTree(node: Tree_node, Population: list):
    if node != None:
        if node.isLeaf():
            Population.append(node)
        PreTree(node.lchild, Population)
        PreTree(node.rchild, Population)




def NBC(Population: list, T: BSPTree):
    PreTree(T.root, Population)
    distanceMatrix = np.full((len(Population), len(Population)), 999, dtype=float)
    graph = np.full((len(Population), len(Population)), 999, dtype=float)
    for i in range(len(Population)):
        for j in range(len(Population)):
            sum = 0
            if i != j:
                for n in range(T.nodeDim):
                    sum = sum + abs(Population[i].paraset[n] - Population[j].paraset[n]) ** 2
                distanceMatrix[i][j] = math.sqrt(sum)

    for i in range(len(Population)):
        dis = 999
        flagP = i
        for j in range(len(Population)):
            if i != j:
                if Population[i].fitness < Population[j].fitness:
                    if distanceMatrix[i][j] < dis:
                        dis = distanceMatrix[i][j]
                        flagP = j
        if dis == 999:
            graph[i][i] = 0
        else:
            graph[i][flagP] = dis
    tempSum = 0
    for i in range(len(Population)):
        for j in range(len(Population)):
            if graph[i][j] != 999:
                tempSum = tempSum + graph[i][j]

    meanDis = tempSum / (len(Population) - 1)
    meanDis = meanDis * 1.2
    for i in range(len(Population)):
        for j in range(len(Population)):
            if graph[i][j] > meanDis:
                graph[i][j] = 999
    return graph, Population


def findcommunity(seat, Population: list, graph):
    for i in range(len(Population)):
        if graph[seat][i] == 0:
            return Population[i]
        if graph[seat][i] != 999:
            seat = i
            return findcommunity(seat, Population, graph)
    return Population[seat]


def CGAS(x: Tree_node, Tree: BSPTree, Population: list, graph):
    y = Tree.getNearestOptim(x)
    alpha = random.random()

    def find(node: Tree_node, Population: list):
        for i in range(len(Population)):
            if Population[i] == node:
                return i
        return -1

    seatY = find(y, Population)
    leader = findcommunity(seatY, Population, graph)
    if all(x.paraset != leader.paraset):
        m = (alpha * x.paraset + (1 - alpha) * leader.paraset)
    else:
        for i in range(len(Population)):
            if graph[i][i] == 0:
                leader = Population[i]
                break
        m = (alpha * x.paraset + (1 - alpha) * leader.paraset)
    return m
