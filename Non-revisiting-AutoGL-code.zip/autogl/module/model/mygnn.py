from autogl.module.model.layer.layer import GeoLayer
import torch
from . import register_model
from .base import BaseModel, activate_func

from typing import Union, Tuple
from torch_geometric.typing import OptPairTensor, Adj, Size

from torch import Tensor
from torch.nn import Linear
import torch.nn.functional as F
from torch_sparse import SparseTensor, matmul
from torch_geometric.nn.conv import GCNConv, GATConv, SplineConv, DynamicEdgeConv, SAGEConv, GINConv, ClusterGCNConv, RGCNConv
from torch.nn import Linear
from ...utils import get_logger
from .GraphNet import GraphNet
LOGGER = get_logger("MYGNNModel")

class MyGNN(GraphNet):
    def __init__(self, args):
        self.args = args
        att_type1=self.args["attType1"]
        att_type2=self.args["attType2"]
        att_type3=self.args["attType3"]
        agg1 = self.args["agg1"]
        agg2 = self.args["agg2"]
        agg3 = self.args["agg3"]
        act1 = self.args["act1"]
        act2 = self.args["act2"]
        act3 = self.args["act3"]
        heads1 = self.args["heads1"]
        heads2 = self.args["heads2"]
        heads3 = self.args["heads3"]
        actions = [
            att_type1, agg1, act1, heads1, self.args["hidden"][0],
            att_type2, agg2, act2, heads2, self.args["hidden"][1],
            att_type3, agg3, act3, heads3, self.args["num_class"]
        ]
        # actions = ['linear', 'sum', 'elu', 2, 32, 'gat_sym', 'sum', 'softplus', 2, 6]
        num_feat = self.args["features_num"]
        num_label = self.args["num_class"]
        drop_out = self.args["dropout"]
        # layer_nums = 3
        state_num = 5
        super(MyGNN, self).__init__(actions, num_feat, num_label, drop_out = drop_out, multi_label=False, batch_normal=False, state_num=state_num, residual=False)
    def forward(self, data):
        try:
            x = data.x
        except:
            print("no x")
            pass
        try:
            edge_index = data.edge_index
        except:
            print("no index")
            pass
        try:
            edge_weight = data.edge_weight
        except:
            edge_weight = None
            pass
        return super().forward(x, edge_index)
        # return super().forward(x, edge_index)


@register_model("mygnn")
class AutoMyGNN(BaseModel):
    def __init__(
        self, num_features=None, num_classes=None, device=None, init=False, **args
    ):

        super(AutoMyGNN, self).__init__()

        self.num_features = num_features if num_features is not None else 0
        self.num_classes = int(num_classes) if num_classes is not None else 0
        self.device = device if device is not None else "cpu"
        self.init = True

        self.params = {
            "features_num": self.num_features,
            "num_class": self.num_classes,
        }
        #Here we define the search space 
        self.space = [
            {
                "parameterName": "num_layers",
                "type": "DISCRETE",
                "feasiblePoints": "3",
            },
            {
                "parameterName": "hidden",
                "type": "NUMERICAL_LIST",
                "numericalType": "INTEGER",
                "length": 2,
                "minValue": [8, 8],
                "maxValue": [256, 256],
                "scalingType": "LOG",
                "cutPara": ("num_layers",),
                "cutFunc": lambda x: x[0] - 1,
            },
            # {
            #     "parameterName": "skip_connect",
            #     "type": "NUMERICAL_LIST",
            #     "numericalType": "INTEGER",
            #     "length": 2,
            #     "minValue": [1,1],
            #     "maxValue": [5,5],
            #     "scalingType": "LINEAR",
            #     "cutPara": ("num_layers",),
            #     "cutFunc": lambda x: x[0] - 1,
            # },
            {
                "parameterName": "attType1",
                "type": "CATEGORICAL",
                "feasiblePoints": ["gat", "gat_sym", "linear", "cos", "generalized_linear",  "const", "gcn", "myatt"],
            },
            {
                "parameterName": "attType2",
                "type": "CATEGORICAL",
                "feasiblePoints": ["gat", "gat_sym", "linear", "cos", "generalized_linear",  "const", "gcn", "myatt"],
            },
            {
                "parameterName": "attType3",
                "type": "CATEGORICAL",
                "feasiblePoints": ["gat", "gat_sym", "linear", "cos", "generalized_linear",  "const", "gcn", "myatt"],
            },
            # {
            #     "parameterName": "convType2",
            #     "type": "CATEGORICAL",
            #     "feasiblePoints": ["GAT", "GCN", "DynamicEdge", "SAGE", "GIN", "ClusterGCN"],
            # },
            # {
            #     "parameterName": "convType3",
            #     "type": "CATEGORICAL",
            #     "feasiblePoints": ["GAT", "GCN", "DynamicEdge", "SAGE", "GIN", "ClusterGCN"],
            # },
            {
                "parameterName": "dropout",
                "type": "DOUBLE",
                "maxValue": 0.8,
                "minValue": 0.2,
                "scalingType": "LINEAR",
            },
            # {
            #     "parameterName": "dropout2",
            #     "type": "DOUBLE",
            #     "maxValue": 0.8,
            #     "minValue": 0.2,
            #     "scalingType": "LINEAR",
            # },
            {
                "parameterName": "act1",
                "type": "CATEGORICAL",
                "feasiblePoints": ["leaky_relu", "relu", "elu", "tanh", "relu6", "softplus"],
            },
            {
                "parameterName": "act2",
                "type": "CATEGORICAL",
                "feasiblePoints": ["leaky_relu", "relu", "elu", "tanh", "relu6", "softplus"],
            },
            {
                "parameterName": "act3",
                "type": "CATEGORICAL",
                "feasiblePoints": ["leaky_relu", "relu", "elu", "tanh", "relu6", "softplus"],
            },
            {
                "parameterName": "agg1",
                "type": "CATEGORICAL",
                "feasiblePoints": ["mean", "sum", "max",]# "mlp", "lstm", "gru"],
            },
            {
                "parameterName": "agg2",
                "type": "CATEGORICAL",
                "feasiblePoints": ["mean", "sum", "max",]# "mlp", "lstm", "gru"],
            },
            {
                "parameterName": "agg3",
                "type": "CATEGORICAL",
                "feasiblePoints": ["mean", "sum", "max",] #"mlp", "lstm", "gru"],
            }
        ]

        self.hyperparams = {
            "num_layers": 2,
            "hidden": [64, 32],
            "dropout": 0.5,
            "attType1": "gat",
            "attType2": "gcn",
            # "attType3": "cos",
            "act1": "relu",
            "act2": "relu",
            # "act3": "relu",
            "agg1": "sum",
            "agg2": "lstm",
            # "agg3": "gru"
        }

        self.initialized = False
        if init is True:
            self.initialize()

    def initialize(self):
        # """Initialize model."""
        if self.initialized:
            return
        self.initialized = True
        self.model = MyGNN({**self.params, **self.hyperparams}).to(self.device)