"""
Some utils used by AutoGL
"""

from .log import get_logger

__all__ = ["get_logger"]
