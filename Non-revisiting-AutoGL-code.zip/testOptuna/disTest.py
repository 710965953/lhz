import math

def get_distance(data1, data2):
    points = zip(data1, data2)
    diffs_squared_distance = [pow(a - b, 2) for (a, b) in points]
    return math.sqrt(sum(diffs_squared_distance))

d1 = [147.86585,26.63250,-3.25139,-6.95435,3.97247,0.35430,1.67268]
d2 = [147.86585,26.63250,-3.04345,-7.09473,4.02826,0.32591,1.67268]

for i in d1:
    i = 1
print(d1)
