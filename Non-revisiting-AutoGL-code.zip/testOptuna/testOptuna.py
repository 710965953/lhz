import random

import optuna
from optuna.distributions import UniformDistribution
def bayesFuncTest():
    def objective(trial):
        max_epoch = trial.suggest_float("max_epoch_", 100, 200)
        early_stopping_round_ =trial.suggest_float("early_stopping_round_",10,30)
        lr_ = trial.suggest_float("lr_",-5.298317366548036,-2.995732273553991)
        weight_decay_ = trial.suggest_float("weight_decay_",-9.210340371976182,-6.907755278982137)
        hidden_0 = trial.suggest_float("hidden_0",3.4657359027997265,4.852030263919617)
        dropout_ = trial.suggest_float("dropout_",0.2,0.8)
        act_ = trial.suggest_float("act_",0,4)
        return max_epoch * 2


    study = optuna.create_study(direction = 'maximize')
    assert len(study.trials) == 0

    paraset = [150,12,-4,-7,3.8,0.5,3]
    trial = optuna.trial.create_trial(
        params = {'max_epoch_':paraset[0],
                  'early_stopping_round_':paraset[1],
                  'lr_':paraset[2],
                  'weight_decay_':paraset[3],
                  'hidden_0':paraset[4],
                  'dropout_':paraset[5],
                  'act_':paraset[6]},
        distributions = {'max_epoch_':UniformDistribution(100,200),
                          'early_stopping_round_':UniformDistribution(10,30),
                          'lr_':UniformDistribution(-5.298317366548036,-2.995732273553991),
                          'weight_decay_':UniformDistribution(-9.210340371976182,-6.907755278982137),
                          'hidden_0':UniformDistribution(3.4657359027997265,4.852030263919617),
                          'dropout_':UniformDistribution(0.2,0.8),
                          'act_':UniformDistribution(0,4)},
        value=300,
    )


    study.add_trial(trial)
    assert len(study.trials) == 1

    study.optimize(objective, n_trials=30)


    # other_study = optuna.create_study()
    #
    # for trial in study.trials:
    #     other_study.add_trial(trial)
    # assert len(other_study.trials) == len(study.trials)
    #
    # other_study.optimize(objective, n_trials=2)
    # assert len(other_study.trials) == len(study.trials) + 2