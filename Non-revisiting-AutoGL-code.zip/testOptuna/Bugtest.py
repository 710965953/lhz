# -*- coding: utf-8 -*-
import geatpy as ea  # 导入geatpy库
import numpy as np
from sys import path as paths
import sys

from optuna.distributions import UniformDistribution

sys.setrecursionlimit(15000) # 设置最大递归深度为15000
from os import path
from .bsd_tree import *
import optuna
class HdEA(ea.SoeaAlgorithm):
    def __init__(self, problem, population):
        ea.SoeaAlgorithm.__init__(self, problem, population)  # 先调用父类构造方法
        if population.ChromNum != 1:
            raise RuntimeError('传入的种群对象必须是单染色体的种群类型。')
        self.name = 'HdEA'
        # self.selFunc = 'rws'
        self.selFunc = "etour"
        # self.selFunc = 'otos'
        if population.Encoding == 'RI':
            # self.mutOper = ea.Mutde(F=0.5)  # 生成差分变异算子对象
            self.recOper = ea.Xovbd(XOVR=0.7, Half_N=True)  # 生成二项式分布交叉算子对象，这里的XOVR即为DE中的Cr
        else:
            raise RuntimeError('编码方式必须为''RI''.')
        self.FitnessTree = BSPTree()
        self.FitnessTree.setMaxandMin(lb = problem.lb, ub = problem.ub)

    def run(self, prophetPop=None):  # prophetPop为先知种群（即包含先验知识的种群）
        # ==========================初始化配置===========================
        population = self.population
        NIND = population.sizes
        self.initialization()  # 初始化算法模板的一些动态参数
        # ===========================准备进化============================
        population.initChrom(NIND)  # 初始化种群染色体矩阵
        self.call_aimFunc(population)  # 计算种群的目标函数值
        # 插入先验知识（注意：这里不会对先知种群prophetPop的合法性进行检查，故应确保prophetPop是一个种群类且拥有合法的Chrom、ObjV、Phen等属性）
        if prophetPop is not None:
            population = (prophetPop + population)[:NIND]  # 插入先知种群
        population.FitnV = ea.scaling(population.ObjV, population.CV, self.problem.maxormins)  # 计算适应度
        # Phen = ea.bs2ri(population.Chrom, population.Field)
        # row, col = Phen.shape
        row, col = population.Chrom.shape
        for i in range(row):
            newNode = Tree_node(fitness=population.FitnV[i], paraset=population.Chrom[i])
            self.FitnessTree.insertNode(newNode)
        self.FitnessTree.buildOptimSet()    #更新optimset
        # print(self.FitnessTree.optimSet)
        # ===========================开始进化============================
        i_n = 0
        while self.terminated(population) == False:
            i_n += 1
            historySolutionNum = i_n * NIND
            self.FitnessTree.setL(min(28, self.FitnessTree.L + 2 * (historySolutionNum // 40)))
            self.FitnessTree.showOptimFitness()
            # self.FitnessTree.drawTreePic('./BSPTree_{}.jpg'.format(i_n))
            MPhen = []
            NBCpopulation = []
            graph, NBCpopulation = NBC(NBCpopulation, self.FitnessTree)
            for i in range(row):
                xnode = self.FitnessTree.searchNode(population.Chrom[i])
                # tempM = GAS(xnode, self.FitnessTree)
                tempM = CGAS(xnode, self.FitnessTree,NBCpopulation,graph)
                MPhen.append(tempM)
            tempChrom = np.array(MPhen)
            experimentPop = ea.Population(population.Encoding, population.Field, NIND)  # 存储试验个体
            ShuffleChrom = tempChrom.copy()
            np.random.shuffle(ShuffleChrom)
            experimentPop.Chrom = self.recOper.do(np.vstack([tempChrom, ShuffleChrom]))  # 重组
            # ############贝叶斯###################
            # PopList = self.FitnessTree.getTreeNode()
            # trials = []
            # for t in PopList:
            #     tempTrail = self.optuna_getTrails(t.paraset,t.fitness)
            #     trials.append(tempTrail)
            # for i in range(len(experimentPop.Chrom)):
            #     for temp in PopList:
            #         points = zip(experimentPop.Chrom[i], temp.paraset)
            #         diffs_squared_distance = [pow(a - b, 2) for (a, b) in points]
            #         dis = math.sqrt(sum(diffs_squared_distance))
            #         if dis < 0.3:
            #             tempParaset,fiv = self.call_bayes(trials)
            #             newParset = []
            #             newParset.append(tempParaset['max_epoch_'])
            #             newParset.append(tempParaset['early_stopping_round_'])
            #             newParset.append(tempParaset['lr_'])
            #             newParset.append(tempParaset['weight_decay_'])
            #             newParset.append(tempParaset['hidden_0'])
            #             newParset.append(tempParaset['dropout_'])
            #             newParset.append(tempParaset['act_'])
            #             experimentPop.Chrom[i] = newParset
            # ######################################
            self.call_aimFunc(experimentPop)  # 计算目标函数值
            tempPop = population + experimentPop
            tempPop.FitnV = ea.scaling(tempPop.ObjV, tempPop.CV, self.problem.maxormins)  # 计算适应度
            population = tempPop[ea.selecting(self.selFunc, tempPop.FitnV, NIND)]  # 采用One-to-One Survivor选择，产生新一代种群
            #print('Now best Fit =', population.FitnV.max())
            for i in range(population.Chrom.shape[0]):
                newNode = Tree_node(fitness=population.FitnV[i], paraset=population.Chrom[i])
                self.FitnessTree.insertNode(newNode)
            self.FitnessTree.buildOptimSet()    #更新optimset
            #print('-------------------',self.FitnessTree.showOptimFitness())
        return self.finishing(population)  # 调用finishing完成后续工作并返回结果


    def optuna_getTrails(self,paraset,Fitv):
        params = {'max_epoch_':paraset[0],
                  'early_stopping_round_':paraset[1],
                  'lr_':paraset[2],
                  'weight_decay_':paraset[3],
                  'hidden_0':paraset[4],
                  'dropout_':paraset[5],
                  'act_':paraset[6]}
        trial = optuna.trial.create_trial(
        params = params,
        distributions={'max_epoch_': UniformDistribution(100, 200),
                       'early_stopping_round_': UniformDistribution(10, 30),
                       'lr_': UniformDistribution(-5.298317366548036, -2.995732273553991),
                       'weight_decay_': UniformDistribution(-9.210340371976182, -6.907755278982137),
                       'hidden_0': UniformDistribution(3.4657359027997265, 4.852030263919617),
                       'dropout_': UniformDistribution(0.2, 0.8),
                       'act_': UniformDistribution(0, 4)},
        value = Fitv
        )
        return trial

